CREATE TRIGGER uye_after_insert
AFTER INSERT ON uye
FOR EACH ROW
  BEGIN

   -- Insert record into audit table
   INSERT INTO anaekransorgu
   ( tc,
     sifre)
   VALUES
   ( NEW.TC,
     NEW.SIFRE );

END;
